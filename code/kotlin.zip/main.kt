
fun main(args: Array<String>) {
  println("Hello world!")
  var sset = HashSet<Set<kotlin.Int>>()
  var s = HashSet<kotlin.Int>(intArrayOf(1, 2, 3).asList())
  sset.add(s)
  println(sset.contains(s))
  //assert(sset.contains(s))
  s.remove(1)
  println(sset.contains(s))
  //assert(sset.contains(s))
  s.add(1)
  println(sset.contains(s))
  //assert(sset.contains(s))
}
