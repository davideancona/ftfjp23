import scala.collection.mutable.HashSet
import scala.collection.Set


object Main {
  def main(args: Array[String]): Unit = {
    println("Hello world!")
    var sset = new HashSet[Set[Int]]()
    var s = new HashSet[Int]()++Array(1,2,3)
    sset.add(s)
    println(s.hashCode())
    assert(sset.contains(s))
    s.remove(1)
        println(s.hashCode())

    //assert(sset.contains(s))
    s.add(1)
        println(s.hashCode())

    assert(sset.contains(s))
  }
}
