using System;
using System.Collections.Generic;
using System.Diagnostics;


class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Hello World");
        var sset = new HashSet<ISet<int>>();
        var s = new HashSet<int>(new int[] { 1, 2, 3 });
        sset.Add(s);
        Debug.Assert(sset.Contains(s));
        s.Remove(1);
        Debug.Assert(sset.Contains(s));
        s.Add(1);
        Debug.Assert(sset.Contains(s));
    }
}